''''
Hi, there 
it's hacker2007
'''
from playsound import playsound
# import pyfiglet module 
import pyfiglet 
result = pyfiglet.figlet_format("Hacker2007 #UH2007", font = "slant" ) 
print(result) 
print('                                                                    Welcome')
print ('''
                                                                    Hi there, 
                                                              My name is Hacker2007
                                                       this is my frist python3 progam you can 
                                                  sent tme mail on hackerhijacker2007@gmail.com .
_______________________________________________________________________________________________________________________________________________________
''')
n = input(" Enter your name: ")
print ( n,"that's ok...\n")

print ("This is just for fun =>\n")

print("Addition of two numbers.")
a = input("Enter a  number: ")
b = input("Again enter a number: ")
a = int(a)
b = int(b)
avg = (a + b)+106
print ("Ths sum of this two numbers is",a+b)
print ("if we add 106 to the answer ths answer is",avg)
print("\n")

print ("Subtraction of two numbers.")
a = input("Enter a number: ")
b = input("Again enter a number: ")
a = int(a)
b = int(b)
avg = (a - b)-107
print ("Ths subtraction of this two numbers is",a-b)
print ("if we subtract 107 to the answer ths answer is",avg)
print("\n")

print ("Division of two numbers.")
a = input("Enter a  number: ")
b = input("Again enter a number: ")
a = int(a)
b = int(b)
avg = (a / b)/108
print ("Ths division of this two numbers is",a+b)
print ("if we divide 108 the answer ths answer is",avg)
print("\n")

print ("Multiplication of two numbers.")
a = input("Enter a  number: ")
b = input("Again enter a number: ")
a = int(a)
b = int(b)
avg = (a * b)*109
print ("Ths multiplication of this two numbers is",a*b)
print ("if we Multiply 109 to the answer ths answer is",avg)
print("\n")

print ("Enter your 6 fruits name.")
f1 = input("Enter fruit number 1: ")
f2 = input("Enter fruit number 2: ")
f3 = input("Enter fruit number 3: ")
f4 = input("Enter fruit number 4: ")
f5 = input("Enter fruit number 5: ")
print("So you like")
mf = [f1, f2, f3, f4, f5]
print(mf)
print("\n")

print('''     
_______________________________________________________________________________________________________________________________________________________
                                                          You can find my some account on :
                                                      Gitlab = https://gitlab.com/hackerhijacker
                                                      Github = https://github.com/hackerhijacker 
                                                    Bitbucket = https://bitbucket.org/hackerhijacker
                                                      
   ''')
playsound ("Play.mp3")
# progam finished  !!!